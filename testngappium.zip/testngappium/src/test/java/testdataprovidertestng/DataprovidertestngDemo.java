package testdataprovidertestng;

import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class DataprovidertestngDemo {
	AppiumServiceBuilder serviceBuilder = new AppiumServiceBuilder();
	AndroidDriver driver;

	@BeforeMethod
	public void demoBeforeMothod() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setPlatformName("Android");
		options.setDeviceName("29221JEGR00379");
		options.setAutomationName(AutomationName.ANDROID_UIAUTOMATOR2);
		options.setAppWaitForLaunch(true);
		options.setAppWaitDuration(Duration.ofMillis(50000));
		options.setAppPackage("com.swaglabsmobileapp");
		options.setAppActivity("com.swaglabsmobileapp.MainActivity");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

	}

	@Test(dataProvider = "testdata2")
	public void testcase001(String username, String password, String search) {
		driver.findElement(AppiumBy.xpath("//android.widget.EditText[@content-desc=\"test-Username\"]")).sendKeys("username");
		driver.findElement(AppiumBy.xpath("//android.widget.EditText[@content-desc=\"test-Password\"]")).sendKeys("password");
		

	}

	// this is how the declaration of the dataprovider will happen as a 2
	// dimensional object array and its always a2 dimentional object array
	// 2 dimentional object array will represent a set of parameters tobe passed to
	// test the methods
	@DataProvider(name = "testdata1")
	public static Object[][] getTestData() {
		return new Object[][] { { "standard_user", "secret_sauce" } };
	}

	@DataProvider(name = "testdata2")
	public static Object[][] getTestData2() {
		return new Object[][] { { "problem_user", "secret_sauce","test1" }, { "locked_out_user", "secret_sauce" ,""}, { "standard_user", "secret_sauce","" } };
	}
	
	@AfterMethod
	public void aftermethod() throws IOException {
		System.out.println("----------Screenshots---------------");
		File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		System.out.println("Paht of the screenshot ---> "+ System.getProperty("user.dir")+"/src/test/resources/screenshot/");
//		Files.copy(screenshot.toPath(), Paths.get(System.getProperty("user.dir")+"/src/test/resources/screenshot/screenshot_"+new Random().nextInt(1000)+".jpg"));
		
		Files.copy(screenshot.toPath(), Paths.get(System.getProperty("user.dir")+"/src/test/resources/screenshot/screenshot_"+new Date().getTime()+".jpg"));
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("this is the before suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().start();
		System.out.println("this is start --------> ");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("this is the after suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().stop();
		System.out.println("this is stop --------> ");
	}
}
