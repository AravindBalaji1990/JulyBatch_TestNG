package testpacktestng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class testngdependentcases {
	@Test(enabled = false)
	public void login() {
		System.out.println("login");
	}

	@Test(dependsOnMethods = "login")
	public void registration() {
		System.out.println("registration");
	}

	@Test(dependsOnMethods = "registration")
	public void validation() {
		System.out.println("validation");
	}


	@BeforeMethod
	public void beforeMethod() {
		System.out.println("before method");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("after method");
	}

}
