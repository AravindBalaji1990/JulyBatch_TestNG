package testpacktestng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class testngpriority {
	@Test(priority = 0)
	public void C() {
		System.out.println("test case1");
	}

	@Test(priority = 3)
	public void A() {
		System.out.println("test case2");
	}

	@Test(priority = 1)
	public void B() {
		System.out.println("test case3");
	}

	@Test(priority = 2,enabled = false)
	public void D() {
		System.out.println("test case4");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("before method");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("after method");
	}

}
