package testpacktestng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class testnggroupingcases {
	@Test(groups = "smoke", enabled = false)
	public void blogin() {
		System.out.println("login");
	}

	@Test(groups ="smoke")
	public void aregistration() {
		System.out.println("registration");
	}

	

	@Test(groups="sanity", dependsOnGroups = "smoke")
	public void validation3() {
		System.out.println("validation3");
	}
	
	@Test(groups="regression")
	public void validation1() {
		System.out.println("validation1");
	}
	@Test(groups="regression")
	public void validation2() {
		System.out.println("validation2");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("before method");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("after method");
	}

}
