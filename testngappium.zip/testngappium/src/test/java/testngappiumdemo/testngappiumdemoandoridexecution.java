package testngappiumdemo;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class testngappiumdemoandoridexecution {
	AppiumServiceBuilder serviceBuilder = new AppiumServiceBuilder();
    AndroidDriver driver ;


	@Test
	public void testcase01() {
		WebElement element = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]\n"));
        new WebDriverWait(driver, Duration.ofSeconds(3)).until(ExpectedConditions.elementToBeClickable(element));
        element.click();
	}



	@BeforeMethod
	public void start() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setPlatformName("Android");
		options.setDeviceName("29221JEGR00379");
		options.setAutomationName(AutomationName.ANDROID_UIAUTOMATOR2);
//	        options.setApp("/Users/aravindbalaji/Documents/Appium/Sample App/android-app.apk");
//	        options.setAppPackage("com.saucelabs.mydemoapp.rn");
//	        options.setAppActivity("com.saucelabs.mydemoapp.rn.MainActivity");
		options.setAppWaitForLaunch(true);
		options.setAppWaitDuration(Duration.ofMillis(50000));
		options.setAppPackage("io.appium.android.apis");
		options.setAppActivity("io.appium.android.apis.ApiDemos");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("this is the before suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().start();
		System.out.println("this is start --------> ");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("this is the after suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().stop();
		System.out.println("this is stop --------> ");
	}

}
