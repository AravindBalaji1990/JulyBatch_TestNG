package testngparameterisation;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

public class ParameterisationDemo {
	AppiumServiceBuilder serviceBuilder = new AppiumServiceBuilder();
	AndroidDriver driver;

	@Test
	@Parameters({"textfield1","textfield2"})
	public void enterTheTextField(String data1, String data2) throws InterruptedException {
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
		Thread.sleep(3000);
		 driver.findElement(new AppiumBy.ByAndroidUIAutomator
               ("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"TextFields\").instance(0))")).click();
		 
		 Thread.sleep(3000);
		 driver.findElement(AppiumBy.xpath("//android.widget.EditText[@resource-id=\"io.appium.android.apis:id/edit\"]")).sendKeys(data1);
		 Thread.sleep(3000);
		 driver.findElement(AppiumBy.xpath("//android.widget.EditText[@resource-id='io.appium.android.apis:id/edit1']")).sendKeys(data2);
		
	}
	

	@BeforeMethod
	public void beforeMethod() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setPlatformName("Android");
		options.setDeviceName("29221JEGR00379");
		options.setAutomationName(AutomationName.ANDROID_UIAUTOMATOR2);
		options.setAppWaitForLaunch(true);
		options.setAppWaitDuration(Duration.ofMillis(50000));
		options.setAppPackage("io.appium.android.apis");
		options.setAppActivity("io.appium.android.apis.ApiDemos");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
	}
	
	@AfterMethod
	public void aftermethod() throws IOException {
		System.out.println("----------Screenshots---------------");
		File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		System.out.println("Paht of the screenshot ---> "+ System.getProperty("user.dir")+"/src/test/resources/screenshot/");
//		Files.copy(screenshot.toPath(), Paths.get(System.getProperty("user.dir")+"/src/test/resources/screenshot/screenshot_"+new Random().nextInt(1000)+".jpg"));
		
		Files.copy(screenshot.toPath(), Paths.get(System.getProperty("user.dir")+"/src/test/resources/screenshot/screenshot_"+new Date().getTime()+".jpg"));
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("this is the before suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().start();
		System.out.println("this is start --------> ");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("this is the after suite");
		serviceBuilder.withAppiumJS(new File("/usr/local/lib/node_modules/appium/build/lib/main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withTimeout(Duration.ofSeconds(120)).build().stop();
		System.out.println("this is stop --------> ");
	}
}
